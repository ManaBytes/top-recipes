# top-recipes
HTML proto recipe page, theodinproject, style to be added but don't (currently) know enough to know what I don't know. You know? 

Get gud git by hub de grub!
Not my first webpage, but first time meaninfully interacting with Git(Hub) past just downloading software.
Before potential longterm use; learn JS, relearn/refresh my CSS, investigate automation and database. 
Manually pushing Git to Hub causes urges to BASH Head into Body. Must understand before automation lest all become black box design. 
Reread gud git practice now that basic undertstanding of workflow.